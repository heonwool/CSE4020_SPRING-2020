Programming Assignment #2 (Cow roller coaster)
Done by Jeongwoo Son (2016024875)

* SimpleScene.py -> CG_practice_assignment_02_2016024875.py
  - File name has been changed to meet the specification written on the Blackboard submit page.

* In CG_practice_assignment_02_2016024875.py
  - Added multiple variables: animStartTime, isTimeInit, cowRollingPos, pickCount, pickLoc, initialPos.
  - Implemented functions: getCatmullRom() and getCowDirection.
  - Modified functions: display(), onMouseButton(), onMouseDrag()